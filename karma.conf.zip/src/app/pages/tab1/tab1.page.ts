import { Component, OnInit } from '@angular/core';
import { NewsService } from '../../services/news.service';
import { ResultadoTopHead } from '../../interfaces/interfaces';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page implements OnInit{
  noticias : ResultadoTopHead;
  constructor( private newsService : NewsService) {}

  ngOnInit(){
    this.newsService.getTopHeadLines().subscribe((resp:ResultadoTopHead) => {
      this.noticias = resp;
      console.log('noticias: ', this.noticias);
    });
    
  }

}
