import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.prod';

@Injectable({
  providedIn: 'root'
})
export class NewsService {

  constructor( private http : HttpClient) { }

  getTopHeadLines(){
    return this.http.get(environment.url+environment.top_head_lines+`?country=mx&apikey=${environment.apy_key}`);
  }
}
