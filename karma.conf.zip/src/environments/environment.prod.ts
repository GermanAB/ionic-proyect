export const environment = {
  production: true,
  apy_key: '06b2b5e50b4f467eba5f769c92eff551',
  url: 'https://newsapi.org',
  top_head_lines: '/v2/top-headlines',
  source: '/v2/sources',
  everything: '/v2/everything'
};
